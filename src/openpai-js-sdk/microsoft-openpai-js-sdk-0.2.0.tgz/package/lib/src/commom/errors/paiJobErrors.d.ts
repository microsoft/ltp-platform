import { PAIBaseError } from './paiBaseError';
/**
 * No job error.
 */
export declare class NoJobError extends PAIBaseError {
}
/**
 * No job config error.
 */
export declare class NoJobConfigError extends PAIBaseError {
}
/**
 * No job config error.
 */
export declare class UnknownError extends PAIBaseError {
}
/**
 * No pod logs error.
 */
export declare class NoTaskLogError extends PAIBaseError {
}
