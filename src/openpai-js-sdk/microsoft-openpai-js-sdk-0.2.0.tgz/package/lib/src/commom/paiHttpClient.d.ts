import { ILoginInfo, IPAICluster } from "../api/v2";
import { AxiosRequestConfig } from 'axios';
import { IPAIResponseProcessor } from './paiResponseProcessor';
/**
 * Http client for PAI rest-server.
 */
export declare class PAIHttpClient {
    protected static readonly TIMEOUT: number;
    protected static readonly EXPIRATION: number;
    private readonly cluster;
    constructor(cluster: IPAICluster);
    /**
     * Login by username and password.
     * @param username Username, set undefined to use the username in cluster setting.
     * @param password Password, set undefined to use the password in cluster setting.
     * @param expiration Expiration time in seconds, default 4000s.
     */
    login(username?: string, password?: string, expiration?: number): Promise<ILoginInfo>;
    get<T>(url: string, processor?: IPAIResponseProcessor, options?: AxiosRequestConfig, query?: object): Promise<T>;
    post<T>(url: string, data: any, processor?: IPAIResponseProcessor, options?: AxiosRequestConfig): Promise<T>;
    put<T>(url: string, data: any, processor?: IPAIResponseProcessor, options?: AxiosRequestConfig): Promise<T>;
    delete<T>(url: string, processor?: IPAIResponseProcessor, options?: AxiosRequestConfig): Promise<T>;
    private defaultOptions;
}
