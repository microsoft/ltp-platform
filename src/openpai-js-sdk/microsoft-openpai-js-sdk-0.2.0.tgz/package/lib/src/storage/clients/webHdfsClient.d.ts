import { IMountInfo, IStorageServer } from "../../api/v2/models/storage";
import { IFileInfo, IStorageNodeClient } from '../models/storageOperation';
/**
 * Web HDFS Client.
 */
export declare class WebHdfsClient implements IStorageNodeClient {
    mkdirAllowRecursive: boolean;
    constructor(_config: IMountInfo, _server: IStorageServer);
    getinfo(_path: string): Promise<IFileInfo>;
    listdir(_path: string): Promise<string[]>;
    makedir(_path: string, _mode?: string | undefined): Promise<void>;
    upload(_localPath: string, _remotePath: string, _opts?: {} | undefined): Promise<void>;
    download(_remotePath: string, _localPath: string, _opts?: {} | undefined): Promise<void>;
    delete(_path: string): Promise<void>;
}
