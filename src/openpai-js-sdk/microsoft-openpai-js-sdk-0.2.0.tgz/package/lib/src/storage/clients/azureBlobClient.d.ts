import { PagedAsyncIterableIterator } from '@azure/core-paging';
import { BlobItem, BlobPrefix, ContainerListBlobHierarchySegmentResponse } from '@azure/storage-blob';
import { IFileInfo, IStorageNodeClient } from '../models/storageOperation';
export type BlobIter = PagedAsyncIterableIterator<({
    kind: 'prefix';
} & BlobPrefix) | ({
    kind: 'blob';
} & BlobItem), ContainerListBlobHierarchySegmentResponse>;
export type BlobEntity = {
    done?: boolean | undefined;
    value: ({
        kind: 'prefix';
    } & BlobPrefix) | ({
        kind: 'blob';
    } & BlobItem);
};
export type BlobValue = ({
    kind: 'prefix';
} & BlobPrefix) | ({
    kind: 'blob';
} & BlobItem);
export interface IAzureBlobCfg {
    containerName: string;
    accountName?: string;
    accountKey?: string;
    accountSASToken?: string;
}
/**
 * Azure Blob Storage Client.
 */
export declare class AzureBlobClient implements IStorageNodeClient {
    mkdirAllowRecursive: boolean;
    private client;
    constructor(data: IAzureBlobCfg);
    /**
     * Get status of a path.
     * @param path The path.
     */
    getinfo(path: string): Promise<IFileInfo>;
    listdir(path: string): Promise<string[]>;
    makedir(path: string, _mode?: string | undefined): Promise<void>;
    upload(localPath: string, remotePath: string, _opts?: {} | undefined): Promise<void>;
    download(remotePath: string, localPath: string, _opts?: {} | undefined): Promise<void>;
    delete(path: string): Promise<void>;
    deleteFolder(path: string): Promise<void>;
    private deleteBlobsByHierarchy;
}
