import { IJobConfig, IJobInfo, IJobStatus, IPAICluster, IPAIResponse } from "..";
import { IEventListQuery, IJobListQeury, ITaskLogInfo } from '../models/job';
import { OpenPAIBaseClient } from './baseClient';
/**
 * OpenPAI Job client.
 */
export declare class JobClient extends OpenPAIBaseClient {
    constructor(cluster: IPAICluster);
    /**
     * Submit a job in the system.
     * @param jobConfig The job config.
     */
    createJob(jobConfig: IJobConfig): Promise<IPAIResponse>;
    /**
     * Submit a job in the system.
     * @param jobConfig The job config.
     */
    createRunningJob(jobConfig: IJobConfig): Promise<IJobInfo>;
    /**
     * Get the list of jobs.
     * @param query filter jobs by username, vc, state and keyword. Set offset, limit, order and withTotalCount.
     */
    listJobs(query?: IJobListQeury): Promise<IJobInfo[] | {
        totalCount: number;
        data: IJobInfo[];
    }>;
    /**
     * Get job status.
     * @param userName The user name.
     * @param jobName The job name.
     * @param jobAttemptId The job attempt id
     */
    getJob(userName: string, jobName: string, jobAttemptId?: number): Promise<IJobStatus>;
    /**
     * Get job configuration.
     * This API always returns job config in v2 format (text/yaml).
     * Old job config in v1 format will be converted automatically.
     * @param userName The user name.
     * @param jobName The job name.
     */
    getJobConfig(userName: string, jobName: string): Promise<IJobConfig>;
    /**
     * Start or stop a job.
     * @param userName The user name.
     * @param jobName The job name.
     * @param type 'START' or 'STOP'.
     */
    updateJobExecutionType(userName: string, jobName: string, type: 'START' | 'STOP'): Promise<any>;
    /**
     * Add a tag.
     * @param userName The user name.
     * @param jobName The job name.
     * @param tag The tag.
     */
    addTag(userName: string, jobName: string, tag: string): Promise<any>;
    /**
     * Delelte a tag.
     * @param userName The user name.
     * @param jobName The job name.
     * @param tag The tag.
     */
    deleteTag(userName: string, jobName: string, tag: string): Promise<any>;
    /**
     * Get task status.
     * @param userName The user name.
     * @param jobName The job name.
     * @param jobAttemptId The job attempt id.
     * @param taskRoleName The task role name.
     * @param taskIndex The task index.
     */
    getTask(userName: string, jobName: string, jobAttemptId: number, taskRoleName: string, taskIndex: number): Promise<IJobStatus>;
    /**
     * Get task logs.
     * @param userName The user name.
     * @param jobName The job name.
     * @param podUid The pod uid.
     */
    getTaskLogs(userName: string, jobName: string, jobAttemptId: number, taskRoleName: string, taskIndex: number, taskAttemptId: number, tailMode?: boolean): Promise<ITaskLogInfo>;
    /**
     * Get the events of a job.
     * @param userName The user name.
     * @param jobName The job name.
     * @param query filter jobs by event type
     */
    listEvents(userName: string, jobName: string, query?: IEventListQuery): Promise<any>;
}
