import { IPAICluster, IPAIClusterInfo } from "..";
import { OpenPAIBaseClient } from './baseClient';
/**
 * OpenPAI Api client.
 */
export declare class AlertClient extends OpenPAIBaseClient {
    constructor(cluster: IPAICluster);
    /**
     * Get OpenPAI cluster info.
     */
    getAlerts(): Promise<IPAIClusterInfo>;
}
