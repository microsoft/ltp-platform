import { ITaskDetail } from "../../../src/api/v2";
/**
 * Task status test data.
 */
export declare const testTaskDetail: ITaskDetail;
