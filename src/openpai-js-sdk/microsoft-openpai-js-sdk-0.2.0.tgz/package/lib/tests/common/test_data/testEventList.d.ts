/**
 * Event list test data.
 */
export declare const testEventList: any;
