import { IApiTestCase, IApiTestItem } from './apiTestCaseGenerator';
import { IOperationResults } from './apiTestRunner';
/**
 * API default test cases will be add to the test case generator.
 */
export declare const ApiDefaultTestCases: {
    [key: string]: IApiTestCase;
};
/**
 * Customized tests
 */
declare class CustomizedTestsClass {
    skipTest(): Promise<void>;
    getTokensWithUnauthorizedUser(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    logoutWithCorrectToken(_test: IApiTestItem, operationResults?: IOperationResults): Promise<void>;
    logoutWithIncorrectToken(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    createUserByNonadminToken(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    createUserByApplicationToken(_test: IApiTestItem, operationResults?: IOperationResults): Promise<void>;
    updateUserByNonadminToken(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    updateUserByApplicationToken(_test: IApiTestItem, operationResults?: IOperationResults): Promise<void>;
    deleteUserByNonadminToken(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    deleteUserByApplicationToken(_test: IApiTestItem, operationResults?: IOperationResults): Promise<void>;
    updateUserGroupByNonadminToken(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    updateUserGroupByApplicationToken(_test: IApiTestItem, operationResults?: IOperationResults): Promise<void>;
    deleteUserGroupByNonadminToken(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    deleteUserGroupByApplicationToken(_test: IApiTestItem, operationResults?: IOperationResults): Promise<void>;
    updateUserGrouplistByNonadminToken(_test: IApiTestItem, _operationResults?: IOperationResults): Promise<void>;
    updateUserGrouplistByApplicationToken(_test: IApiTestItem, operationResults?: IOperationResults): Promise<void>;
    private userClientOperationByApplicationToken;
    private userClientOperationByNonadminToken;
    private createNonadminUserAndToken;
    private deleteNonadminUserAndToken;
}
export declare const CustomizedTests: CustomizedTestsClass;
export {};
