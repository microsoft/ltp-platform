import { OpenPAIClient } from "../../src/api/v2";
import { Ajv } from 'ajv';
import { IApiOperation } from './apiTestCaseGenerator';
export interface IOperationResults {
    beforeEachResults: any[];
    beforeResults: any[];
    testResults: any[];
}
/**
 * Api test runner.
 */
export declare class ApiTestRunner {
    private openPAIClient;
    private map;
    private ajvInstance;
    private mock;
    constructor(openPAIClient: OpenPAIClient, ajvInstance: Ajv, map?: any, mock?: any);
    getClientName(tag: string): string;
    runOperation(operation: IApiOperation, operationResults?: IOperationResults): Promise<any>;
    runOperations(operations?: IApiOperation[], operationResults?: IOperationResults): Promise<any>;
    private mockExample;
}
